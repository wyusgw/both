first buy ubuntu 20.04 server

and install mysql


1- mysql
2- CREATE DATABASE succubus;
3- quit;

and type "mysql -u root succubus < database.sql"

make your password "root"

Change sql user and pass in config/succubus.json

ulimit -n100000
screen ./main